﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * Form object holding list of components
 */

namespace Project_3_Starter
{
    public class Form
    {
        private List<IFormComponent> components;

        public Form()
        {
            components = new List<IFormComponent>();
        }

        public void AddComponent(IFormComponent c)
        {
            components.Add(c);
        }

        public IFormComponent GetComponent(int index)
        {
            return components[index];
        }
    }
}
