﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * Abstract class defining the Two possible states
 */

namespace Project_3_Starter
{
    public abstract class State
    {
        protected FormInput form;
        public State(FormInput f)
        {
            form = f;
        }

        public abstract void Run();
    }
}
