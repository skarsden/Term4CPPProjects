﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * Done state runs after Input state has finshed, allows user to print or reset
 */

namespace Project_3_Starter
{
    public class DoneState : State
    {
        public DoneState(FormInput f) : base(f)
        {
        }

        public override void Run()
        {
            Console.WriteLine();
            Console.WriteLine("Type 'print' to print the form, or 'exit' to leave");

            string input;

            while (true)
            {
                Console.Write(">");
                input = Console.ReadLine();
                //print form
                if (input.ToLower().Equals("print"))
                {
                    Console.WriteLine();
                    for (int i = 0; i <= 5; i++)
                    {
                        Console.WriteLine(form.GetForm().GetComponent(i).GetName() + ": " + form.GetForm().GetComponent(i).GetValue());
                    }
                    Console.WriteLine();
                }
                //end program
                else if (input.ToLower().Equals("exit"))
                    break;
                else
                {
                    Console.WriteLine("Invalid entry, try again");
                }
            }

        }
    }
}
