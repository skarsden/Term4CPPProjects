﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * Input state for running user inputs, changed to Done state when finished
 */

namespace Project_3_Starter
{
    public class InputState : State
    {
        public InputState(FormInput f) : base(f)
        {
        }

        public override void Run()
        {
            //print title, declare needed variables
            Console.WriteLine("Welcome to the From Creator");
            Console.WriteLine();
            string input;
            int index = 0;

            //use loop to iterate through, print, and set values for components
            while (index <= 5)
            {
                Console.WriteLine(form.GetForm().GetComponent(index).GetName() + ":");
                while (true)
                {
                    Console.Write(">");
                    input = Console.ReadLine();
                    form.GetForm().GetComponent(index).SetValue(input);
                    if (form.GetForm().GetComponent(index).isValid())
                        break;
                    Console.WriteLine("Invalid entry, try again");
                }
                index++;
            }

            //confirming entries
            Console.WriteLine();
            Console.WriteLine("All forms filled. Please confirm entries:\n");

            for(int i = 0; i <= 5; i++)
            {
                Console.WriteLine(form.GetForm().GetComponent(i).GetName() + ": " + form.GetForm().GetComponent(i).GetValue());
            }

            Console.WriteLine();
            Console.WriteLine("Type 'reset' to reset or 'ok' to proceed");

            while (true)
            {
                Console.Write(">");
                input = Console.ReadLine();
                if (input.ToLower().Equals("reset"))
                {
                    //re-do InputState
                    Console.WriteLine();
                    form.Run();
                    break;
                }
                else if (input.ToLower().Equals("ok"))
                {
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid entry, try again");
                }
            }

            form.ChangeState(new DoneState(form));
            form.Run();
        }
    }
}
