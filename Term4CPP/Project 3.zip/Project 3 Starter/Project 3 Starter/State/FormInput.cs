﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * FormInput accesses/changes state depending on user progress, holds Form object
 */

namespace Project_3_Starter
{
    public class FormInput
    {
        private Form list;
        private State state;
        public FormInput(Form list)
        {
            this.list = list;
            state = new InputState(this);
        }

        //run currently set state
        public void Run()
        {
            state.Run();
        }

        //get form components
        public Form GetForm()
        {
            return list;
        }

        //change state
        public void ChangeState(State state)
        {
            this.state = state;
        }
    }
}
