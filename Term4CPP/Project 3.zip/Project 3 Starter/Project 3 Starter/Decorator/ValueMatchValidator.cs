﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * Validator for previous user inputs
 */

namespace Project_3_Starter
{
    public class ValueMatchValidator : Validator
    {
        IFormComponent comp;
        public ValueMatchValidator(IFormComponent c, IFormComponent comp) : base(c)
        {
            this.comp = comp;
        }

        public override string GetName()
        {
            return component.GetName();
        }

        public override string GetValue()
        {
            return component.GetValue();
        }

        public override bool isValid()
        {
            if (component.GetValue().Equals(comp.GetValue()))
                return component.isValid();
            else
                return false;
        }

        public override void SetValue(string value)
        {
            component.SetValue(value);
        }
    }
}
