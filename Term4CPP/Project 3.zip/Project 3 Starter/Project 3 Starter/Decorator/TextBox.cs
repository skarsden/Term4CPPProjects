﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * TextBox component for holding user input
 */

namespace Project_3_Starter
{
    public class TextBox : IFormComponent
    {
        private string name;
        private string value;

        public TextBox(string name)
        {
            this.name = name;
        }
        public string GetName()
        {
            return name;
        }

        public string GetValue()
        {
            return value;
        }

        public bool isValid()
        {
            return true;
        }

        public void SetValue(string value)
        {
            this.value = value;
        }
    }
}
