﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * Form Component Interface defining the TextBox and Valiator classes
 */

namespace Project_3_Starter
{
    public interface IFormComponent
    {
        public string GetName();
        public string GetValue();
        public void SetValue(string value);
        public bool isValid();
    }
}
