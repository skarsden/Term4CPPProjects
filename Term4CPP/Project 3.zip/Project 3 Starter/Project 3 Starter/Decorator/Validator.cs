﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * Abstract class defining valdiators
 */

namespace Project_3_Starter
{
    public abstract class Validator : IFormComponent
    {
        protected IFormComponent component;

        public Validator(IFormComponent c) { 
            component = c; 
        }

        public abstract string GetName();
        public abstract string GetValue();
        public abstract bool isValid();
        public abstract void SetValue(string value);
    }
}
