﻿using Microsoft.VisualBasic.CompilerServices;
using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * Validator component for numbers
 */

namespace Project_3_Starter
{
    public class NumberValidator : Validator
    {
        int age;
        public NumberValidator(IFormComponent c) : base(c)
        {
        }

        public override string GetName()
        {
            return component.GetName();
        }

        public override string GetValue()
        {
            return component.GetValue();
        }

        public override bool isValid()
        {
            if (int.TryParse(component.GetValue(), out age))
                return component.isValid();
            else
                return false;
        }

        public override void SetValue(string value)
        {
            component.SetValue(value);
        }
    }
}
