﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * Validator component for individual characters
 */

namespace Project_3_Starter
{
    public class CharacterValidator : Validator
    {
        private string charToCheck;
        public CharacterValidator(IFormComponent c, string ctc) : base(c) {
            charToCheck = ctc;
        }

        public override string GetName()
        {
            return component.GetName();
        }

        public override string GetValue()
        {
            return component.GetValue();
        }

        public override bool isValid()
        {
            if (component.GetValue().Contains(charToCheck))
                return component.isValid();
            else
                return false;
        }

        public override void SetValue(string value)
        {
            component.SetValue(value);
        }
    }
}
