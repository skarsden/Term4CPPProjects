﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * August 12, 2020
 * Validator component for user input length
 */

namespace Project_3_Starter
{
    public class MinLengthValidator : Validator
    {
        private int minLength;
        public MinLengthValidator(IFormComponent c, int minLength) : base(c)
        {
            this.minLength = minLength;
        }

        public override string GetName()
        {
            return component.GetName();
        }

        public override string GetValue()
        {
            return component.GetValue();
        }

        public override bool isValid()
        {
            if (component.GetValue().Length >= minLength)
                return component.isValid();
            else
                return false;
        }

        public override void SetValue(string value)
        {
            component.SetValue(value);
        }
    }
}
