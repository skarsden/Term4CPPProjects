﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * July 21, 2020
 * Project 2
 * JSONBranch - Branch class for JSON implementation
 */

namespace DocumentBuilderLibrary
{
    public class JSONBranch : IComposite
    {
        private string name;
        private List<IComposite> children;

        public JSONBranch(string n)
        {
            name = n;
            children = new List<IComposite>();
        }
        public void AddChild(IComposite child)
        {
            children.Add(child);
        }

        public string Print(int depth)
        {
            string branch = "";

            for (int i = 0; i < depth; i++)
                branch += "\t";

            if (!name.Equals("root"))
                branch += $"'{name}' : \n";

            for (int i = 0; i < depth; i++)
                branch += "\t";
            branch += "{\n";

            foreach (IComposite child in children)
                branch += child.Print(depth + 1);

            for (int i = 0; i < depth; i++)
                branch += "\t";
            branch += "}\n";

            return branch;
        }
    }
}
