﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * July 21, 2020
 * Project 2
 * XMLBranch - Branch class for XML implementation
 */

namespace DocumentBuilderLibrary
{
    class XMLBranch : IComposite
    {
        private string name;
        private List<IComposite> children;

        public XMLBranch(string n)
        {
            name = n;
            children = new List<IComposite>();
        }
        public void AddChild(IComposite child)
        {
            children.Add(child);
        }

        public string Print(int depth)
        {
            string branch = "";

            for (int i = 0; i < depth; i++)
                branch += "\t";
            branch += $"<{name}>\n";

            foreach (IComposite child in children)
                branch += child.Print(depth + 1);

            for (int i = 0; i < depth; i++)
                branch += "\t";
            branch += $"</{name}>\n";

            return branch;
        }
    }
}
