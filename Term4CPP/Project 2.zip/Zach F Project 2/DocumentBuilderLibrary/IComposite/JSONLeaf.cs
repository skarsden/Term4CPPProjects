﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * July 21, 2020
 * Project 2
 * JSONLeaf - Leaf class for JSON implementation
 */

namespace DocumentBuilderLibrary
{
    public class JSONLeaf : IComposite
    {
        private string name;
        private string content;

        public JSONLeaf(string n, string c)
        {
            name = n;
            content = c;
        }
        public void AddChild(IComposite child)
        {
            Console.WriteLine("Error: Leaf objects cannot have children");
        }

        public string Print(int depth)
        {
            string leaf = "";
            for (int i = 0; i < depth; i++)
                leaf += "\t";
            leaf += $"'{name}' : '{content}'\n";
            return leaf;
        }
    }
}
