﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * July 21, 2020
 * Project 2
 * IComposite - interface from which branch and leaf classes inherit
 */

namespace DocumentBuilderLibrary
{
    public interface IComposite
    {
        void AddChild(IComposite child);
        string Print(int depth);
    }
}
