﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * July 21, 2020
 * Project 2
 * XMLLeaf - Leaf class for XML implementation
 */

namespace DocumentBuilderLibrary
{
    class XMLLeaf : IComposite
    {
        private string name;
        private string content;
        public XMLLeaf(string n, string c)
        {
            name = n;
            content = c;
        }
        public void AddChild(IComposite child)
        {
            Console.WriteLine("Error: Leaf objects cannot have children");
        }

        public string Print(int depth)
        {
            string leaf = "";
            for (int i = 0; i < depth; i++)
                leaf += "\t";
            leaf += $"<{name}>{content}</{name}>\n";
            return leaf;
        }
    }
}
