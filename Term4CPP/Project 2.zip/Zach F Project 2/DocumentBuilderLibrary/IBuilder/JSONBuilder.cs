﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * July 21, 2020
 * Project 2
 * JSONBuilder - Builder class for JSON implementation
 */

namespace DocumentBuilderLibrary
{
    public class JSONBuilder : IBuilder
    {
        private JSONBranch root;
        private JSONBranch currentBranch;

        private Stack<JSONBranch> parents = new Stack<JSONBranch>();

        public JSONBuilder()
        {
            root = new JSONBranch("root");
            currentBranch = root;
        }

        public void BuildBranch(string name)
        {
            JSONBranch newBranch = new JSONBranch(name);
            currentBranch.AddChild(newBranch);
            parents.Push(currentBranch);
            currentBranch = newBranch;
        }

        public void BuildLeaf(string name, string content)
        {
            JSONLeaf newLeaf = new JSONLeaf(name, content);
            currentBranch.AddChild(newLeaf);
        }

        public void CloseBranch()
        {
            if(parents.Count == 0)
            {
                Console.WriteLine("Error: Alread at root");
                return;
            }
            currentBranch = parents.Pop();
        }

        public IComposite GetDocument()
        {
            return root;
        }
    }
}
