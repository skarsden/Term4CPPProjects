﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

/* Zach Francis
 * July 21, 2020
 * Project 2
 * IBuilder - Interface from which concrete builders inherit
 */

namespace DocumentBuilderLibrary
{
    public interface IBuilder
    {
        void BuildBranch(string name);
        void BuildLeaf(string name, string content);
        void CloseBranch();
        IComposite GetDocument();
    }
}
