﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * July 21, 2020
 * Project 2
 * XMLBuilder - Builder class for XML implementation
 */

namespace DocumentBuilderLibrary
{
    public class XMLBuilder : IBuilder
    {
        private XMLBranch root;
        private XMLBranch currentBranch;

        private Stack<XMLBranch> parents = new Stack<XMLBranch>();

        public XMLBuilder()
        {
            root = new XMLBranch("root");
            currentBranch = root;
        }

        public void BuildBranch(string name)
        {
            XMLBranch newBranch = new XMLBranch(name);
            currentBranch.AddChild(newBranch);
            parents.Push(currentBranch);
            currentBranch = newBranch;
        }

        public void BuildLeaf(string name, string content)
        {
            XMLLeaf newLeaf = new XMLLeaf(name, content);
            currentBranch.AddChild(newLeaf);
        }

        public void CloseBranch()
        {
            if(parents.Count == 0)
            {
                Console.WriteLine("Error: Already at root");
                return;
            }
            currentBranch = parents.Pop();
        }

        public IComposite GetDocument()
        {
            return root;
        }
    }
}
