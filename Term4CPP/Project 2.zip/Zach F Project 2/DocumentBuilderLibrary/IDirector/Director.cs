﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

/* Zach Francis
 * July 21, 2020
 * Project 2
 * Director - the concrete implementation of IDirector the user can access the builder from
 */

namespace DocumentBuilderLibrary
{
    public class Director : IDirector
    {
        IBuilder builder;
        private string name = "";
        private string content = "";

        public Director(string type)
        {
            if (type.Equals("XML"))
            {
                builder = new XMLBuilder();
            }
            else if (type.Equals("JSON"))
            {
                builder = new JSONBuilder();
            }
        }
        public void BuildBranch()
        {
            builder.BuildBranch(name);
        }

        public void BuildLeaf()
        {
            builder.BuildLeaf(name, content);
        }

        public void PrintDoc()
        {
            Console.Write(builder.GetDocument().Print(0));
        }

        public void CloseBranch()
        {
            builder.CloseBranch();
        }

        public void SetName(string n)
        {
            name = n;
        }

        public void SetContent(string c)
        {
            content = c;
        }
    }
}
