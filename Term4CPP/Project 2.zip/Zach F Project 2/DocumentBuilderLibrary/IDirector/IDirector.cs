﻿using System;
using System.Collections.Generic;
using System.Text;

/* Zach Francis
 * July 21, 2020
 * Project 2
 * IDirector - interface from which Director inherits
 */

namespace DocumentBuilderLibrary
{
    public interface IDirector
    {
        void BuildBranch();
        void BuildLeaf();
        void CloseBranch();
    }
}
