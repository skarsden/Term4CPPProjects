﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;
using DocumentBuilderLibrary;

/* Zach Francis
 * July 21, 2020
 * Project 2
 * Program.cs - the Console Client from which the user can interact with the program
 */

namespace Zach_F_Project_2
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Document Builder Console Client");
            Console.WriteLine();

            printHelp();

            bool takingInput = true;
            bool buildingDoc = false;
            bool exit = false;
            string input;
            string[] command = new string[4];
            Director director;

            //input loop without mode set
            while (takingInput)
            {
                Console.Write(">");
                input = Console.ReadLine();
                command = input.Split(':');

                //exit command
                if (command[0].Equals("exit"))
                    break;

                //help command
                else if (command[0].Equals("help"))
                {
                    Console.WriteLine();
                    printHelp();
                    Console.WriteLine();
                    continue;
                }

                //trying to use document commands without building a document
                else if (command[0].Equals("branch") || command[0].Equals("leaf") || command[0].Equals("close") || command[0].Equals("print"))
                {
                    Console.WriteLine();
                    Console.WriteLine("Error: No mode selected, type 'help' for commands");
                    Console.WriteLine();
                    continue;
                }

                //setting mode and building document
                else if (command[0].Equals("mode") && command.Length == 2)
                {
                    //XML MODE---------------------------------------------------------------------------
                    if (command[1].Equals("XML"))
                    {
                        director = new Director("XML");
                        buildingDoc = true;

                        //input loop with XML mode set
                        while (buildingDoc)
                        {
                            Console.Write(">");
                            input = Console.ReadLine();
                            command = input.Split(':');

                            //if user has entered valid command
                            //exit program
                            if (command[0].Equals("exit") && command.Length == 1)
                            {
                                exit = true;
                                break;
                            }
                            //print command list
                            else if (command[0].Equals("help") && command.Length == 1)
                            {
                                printHelp();
                                continue;
                            }
                            //build branch
                            if (command[0].Equals("branch") && command.Length == 2)
                            {

                                director.SetName(command[1]);
                                director.BuildBranch();
                            }
                            //build leaf
                            else if (command[0].Equals("leaf") && command.Length == 3)
                            {
                                director.SetName(command[1]);
                                director.SetContent(command[2]);
                                director.BuildLeaf();
                            }
                            //close branch
                            else if (command[0].Equals("close") && command.Length == 1)
                            {
                                director.CloseBranch();
                            }
                            //print document
                            else if (command[0].Equals("print") && command.Length == 1)
                            {
                                director.PrintDoc();
                            }
                            //user hasn't entered valid command
                            else
                            {
                                Console.WriteLine();
                                Console.WriteLine("Error: Invalid input, enter 'help' for commands");
                                Console.WriteLine();
                            }
                        }
                    }//END XML MODE---------------------------------------------------------------------------

                    //JSON MODE---------------------------------------------------------------------------
                    else if (command[1].Equals("JSON"))
                    {
                        director = new Director("JSON");
                        buildingDoc = true;

                        //input loop with JSON mode set
                        while (buildingDoc)
                        {
                            Console.Write(">");
                            input = Console.ReadLine();
                            command = input.Split(':');

                            //if user has entered valid command
                            //exit program
                            if (command[0].Equals("exit") && command.Length == 1)
                            {
                                exit = true;
                                break;
                            }
                            //print command list
                            else if (command[0].Equals("help") && command.Length == 1)
                            {
                                printHelp();
                                continue;
                            }
                            //build branch
                            if (command[0].Equals("branch") && command.Length == 2)
                            {

                                director.SetName(command[1]);
                                director.BuildBranch();
                            }
                            //build leaf
                            else if (command[0].Equals("leaf") && command.Length == 3)
                            {
                                director.SetName(command[1]);
                                director.SetContent(command[2]);
                                director.BuildLeaf();
                            }
                            //close branch
                            else if (command[0].Equals("close") && command.Length == 1)
                            {
                                director.CloseBranch();
                            }
                            //print document
                            else if (command[0].Equals("print") && command.Length == 1)
                            {
                                director.PrintDoc();
                            }
                            //user hasn't entered valid command
                            else
                            {
                                Console.WriteLine();
                                Console.WriteLine("Error: Invalid input, enter 'help' for commands");
                                Console.WriteLine();
                            }
                        }
                    }//END JSON MODE---------------------------------------------------------------------------
                    //user hasn't entered valid command
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("Error: Invalid input, enter 'help' for commands");
                        Console.WriteLine();
                    }

                }
                //user hasn't entered valid command
                else
                {
                    Console.WriteLine();
                    Console.WriteLine("Error: Invalid input, enter 'help' for commands");
                    Console.WriteLine();
                }

                if (exit)
                    break;
            }
        }

        //prints out commands 
        public static void printHelp()
        {
            Console.WriteLine("Commands:");

            Console.WriteLine("\thelp\t\t\t-prints command list");
            Console.WriteLine("\tmode:<JSON|XML>\t\t-Sets mode to JSON or XML. Must be set before creating or closing");
            Console.WriteLine("\tbranch:<name>\t\t-creates a new branch, assigning the passed name");
            Console.WriteLine("\tleaf:<name>:<content>\t-creates a new leaf, assiging the passed name and content");
            Console.WriteLine("\tclose\t\t\t-closes the current branch, as long as it's not the root");
            Console.WriteLine("\tprint\t\t\t-prints the document in its current state to the console");
            Console.WriteLine("\texit\t\t\t-exits the application");
            Console.WriteLine();

            Console.WriteLine("Reminder: Commands are case sensitive");
            Console.WriteLine();
        }
    }
}
